var searchData=
[
  ['gamepad_20axes',['Gamepad axes',['../group__gamepad__axes.html',1,'']]],
  ['gamepad_20buttons',['Gamepad buttons',['../group__gamepad__buttons.html',1,'']]]
];
