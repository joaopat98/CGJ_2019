﻿#include "mesh.h"

vector <vec3> Vertices, vertexData;
vector <vec2> Texcoords, texcoordData;
vector <vec3> Normals, normalData;

bool TexcoordsLoaded, NormalsLoaded;

vector <unsigned int> vertexIdx, texcoordIdx, normalIdx;

void parseVertex(stringstream& sin)
{
	vec3 v;
	sin >> v.x >> v.y >> v.z;
	vertexData.push_back(v);
}

void parseTexcoord(stringstream& sin)
{
	vec2 t;
	sin >> t.x >> t.y;
	texcoordData.push_back(t);
}

void parseNormal(stringstream& sin)
{
	vec3 n;
	sin >> n.x >> n.y >> n.z;
	normalData.push_back(n);
}

void parseFace(stringstream& sin)
{
	string token;
	if (normalData.empty() && texcoordData.empty())
	{
		for (int i = 0; i < 3; i++)
		{
			sin >> token;
			vertexIdx.push_back(stoi(token));
		}
	}
	else
	{
		for (int i = 0; i < 3; i++)
		{
			getline(sin, token, '/');
			if (token.size() > 0)
				vertexIdx.push_back(stoi(token));
			getline(sin, token, '/');
			if (token.size() > 0)
				texcoordIdx.push_back(stoi(token));
			getline(sin, token, ' ');
			if (token.size() > 0)
				normalIdx.push_back(stoi(token));
		}
	}
}

void parseLine(stringstream& sin)
{
	string s;
	sin >> s;
	if (s.compare("v") == 0) parseVertex(sin);
	else if (s.compare("vt") == 0) parseTexcoord(sin);
	else if (s.compare("vn") == 0) parseNormal(sin);
	else if (s.compare("f") == 0) parseFace(sin);
}

void loadMeshData(string& filename)
{
	ifstream ifile(filename);
	string line;
	bool good = ifile.bad();
	while (getline(ifile, line)) {
		stringstream sline(line);
		parseLine(sline);
	}
	TexcoordsLoaded = (texcoordIdx.size() > 0);
	NormalsLoaded = (normalIdx.size() > 0);
}

void processMeshData()
{
	for (unsigned int i = 0; i < vertexIdx.size(); i++) {
		unsigned int vi = vertexIdx[i];
		vec3 v = vertexData[vi - 1];
		Vertices.push_back(v);
		if (TexcoordsLoaded) {
			unsigned int ti = texcoordIdx[i];
			vec2 t = texcoordData[ti - 1];
			Texcoords.push_back(t);
		}
		if (NormalsLoaded) {
			unsigned int ni = normalIdx[i];
			vec3 n = normalData[ni - 1];
			Normals.push_back(n);
		}
	}
}

void freeMeshData()
{
	vertexData.clear();
	texcoordData.clear();
	normalData.clear();
	vertexIdx.clear();
	texcoordIdx.clear();
	normalIdx.clear();
}

const void createMesh(string& filename)
{
	loadMeshData(filename);
	processMeshData();
	freeMeshData();
}

/////////////////////////////////////////////////////////////////////// VAOs & VBOs

void createBufferObjects(Program program, GLuint *VaoId)
{
	GLuint VboVertices, VboTexcoords, VboNormals;

	glGenVertexArrays(1, VaoId);
	glBindVertexArray(*VaoId);
	{
		glGenBuffers(1, &VboVertices);
		glBindBuffer(GL_ARRAY_BUFFER, VboVertices);
		glBufferData(GL_ARRAY_BUFFER, Vertices.size() * sizeof(vec3), &Vertices[0], GL_STATIC_DRAW);
		glEnableVertexAttribArray(program.attribs["inPosition"]);
		glVertexAttribPointer(program.attribs["inPosition"], 3, GL_FLOAT, GL_FALSE, sizeof(vec3), 0);

		if (false)
		{
			glGenBuffers(1, &VboTexcoords);
			glBindBuffer(GL_ARRAY_BUFFER, VboTexcoords);
			glBufferData(GL_ARRAY_BUFFER, Texcoords.size() * sizeof(vec2), &Texcoords[0], GL_STATIC_DRAW);
			glEnableVertexAttribArray(program.attribs["inTexcoord"]);
			glVertexAttribPointer(program.attribs["inTexcoord"], 2, GL_FLOAT, GL_FALSE, sizeof(vec2), 0);
		}
		if (NormalsLoaded)
		{
			glGenBuffers(1, &VboNormals);
			glBindBuffer(GL_ARRAY_BUFFER, VboNormals);
			glBufferData(GL_ARRAY_BUFFER, Normals.size() * sizeof(vec3), &Normals[0], GL_STATIC_DRAW);
			glEnableVertexAttribArray(program.attribs["inNormal"]);
			glVertexAttribPointer(program.attribs["inNormal"], 3, GL_FLOAT, GL_FALSE, sizeof(vec3), 0);
		}
	}
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void destroyBufferObjects(Program program, GLuint *VaoId)
{
	glBindVertexArray(*VaoId);
	program.removeAttrib("inPosition");
	program.removeAttrib("inTexcoord");
	program.removeAttrib("inNormal");
	glDeleteVertexArrays(1, VaoId);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

Mesh::Mesh()
{
}

Mesh Mesh::fromObj(Program program, string path) {
	Mesh m;
	createMesh(path);
	createBufferObjects(program, &m.vaoId);
	m.numTris = (int)Vertices.size();
	Vertices.clear();
	Texcoords.clear();
	Normals.clear();
	return m;
}

void Mesh::draw()
{
	glBindVertexArray(vaoId);
	glFrontFace(GL_CW);
	glDrawArrays(GL_TRIANGLES, 0, (GLsizei)numTris);
}

void Mesh::destroy(Program program)
{
	destroyBufferObjects(program, &vaoId);
}
